package com.phudnguyen.dusttracker.http;

import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.IOException;
import java.util.concurrent.atomic.AtomicReference;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class HttpHelper {
    private static final String TAG = HttpHelper.class.getSimpleName();
    private static final Gson GSON = new GsonBuilder().create();
    public static AtomicReference<String> JWT = new AtomicReference<>();

    public static <T> T post(String url, Object data, Class<T> responseClass) throws IOException {
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
            .url(url)
            .addHeader("Authorization", JWT.get())
            .post(RequestBody.create(MediaType.get("application/json"), GSON.toJson(data)))
            .build();
        Response response = client.newCall(request).execute();
        String body = response.body().string();
        Log.i(TAG, body);
        return GSON.fromJson(body, responseClass);
    }

    public static <T> T get(String url, Class<T> responseClass) throws Exception {
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
            .get()
            .url(url)
            .addHeader("Authorization", JWT.get())
            .build();
        Response response = client.newCall(request).execute();
        String body = response.body().string();
        Log.i(TAG, body);
        return GSON.fromJson(body, responseClass);
    }


}
